var typed = new Typed(('.skills'),{
    strings:['Frontend Developer','Gamer','Student','Rider','Video Editer'],
    typespeed : 100,
    backspeed : 100,
    backDelay : 1000,
    loop : true,
});